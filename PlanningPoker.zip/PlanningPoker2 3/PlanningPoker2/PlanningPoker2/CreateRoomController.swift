//
//  CreateRoomController.swift
//  PlanningPoker2
//
//  Created by Mitzi Davis on 11/23/16.
//  Copyright (c) 2016 Joshua Davis. All rights reserved.
//

import UIKit

class CreateRoomController: UIViewController {
    @IBOutlet weak var roomName: UITextField!
    var roomNameString: String!
    var roomPWString: String!
    //var roomPW: Int!
    var upper_bound = 100000
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let roomPW = arc4random_uniform(100000)
        roomPWString = String(roomPW)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func createRoom(sender: AnyObject) {
        
        roomNameString = roomName.text!
        createTable()
        performSegueWithIdentifier("createToHostSegue", sender: nil)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue,sender: AnyObject!) {
        let hvc = segue.destinationViewController as! HostViewController;
        hvc.roomName = roomNameString
        hvc.password = roomPWString
    }

    func createTable(){
        let url = "http://web-students.armstrong.edu/~jd8944/gulfstream2/createroom.php?roomname=\(roomNameString)&roompw=\(roomPWString)"
        let request = NSMutableURLRequest(URL: NSURL(string:url)!)
        request.HTTPMethod = "POST"
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in guard error == nil && data != nil else {
            // check for fundamental networking error
            print("error=\(error)")
            return
            }
        }
        task.resume()
    }
}
