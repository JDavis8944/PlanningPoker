//
//  ViewController.swift
//  PlanningPoker2
//
//  Created by Mitzi Davis on 11/23/16.
//  Copyright (c) 2016 Joshua Davis. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

