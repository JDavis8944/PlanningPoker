//
//  MemberViewController.swift
//  PlanningPoker2
//
//  Created by Mitzi Davis on 11/23/16.
//  Copyright (c) 2016 Joshua Davis. All rights reserved.
//

import UIKit

class MemberViewController: UIViewController {
    
    var roomName: String!
    var fName: String!
    var lName: String!
    var vote: Int!
    
    @IBOutlet weak var infinityButton: UIButton!
    @IBOutlet weak var twoButton: UIButton!
    @IBOutlet weak var thirteenButton: UIButton!
    @IBOutlet weak var fiveButton: UIButton!
    @IBOutlet weak var eightButton: UIButton!
    @IBOutlet weak var oneButton: UIButton!
    @IBOutlet weak var thirtyFourButton: UIButton!
    @IBOutlet weak var fiftyFiveButton: UIButton!
    @IBOutlet weak var twentyOneButton: UIButton!
    @IBOutlet weak var threeButton: UIButton!
    @IBOutlet weak var halfButton: UIButton!
    @IBOutlet weak var zeroButtonOutlet: UIButton!
    @IBOutlet weak var eightyNineButton: UIButton!
    @IBOutlet weak var oneFourtyFourButton: UIButton!
    @IBOutlet weak var questionButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        zeroButtonOutlet.tag = 0
        halfButton.tag = 100
        oneButton.tag = 1
        twoButton.tag = 2
        threeButton.tag = 3
        fiveButton.tag = 5
        eightButton.tag = 8
        thirteenButton.tag = 13
        twentyOneButton.tag = 21
        thirtyFourButton.tag = 34
        fiftyFiveButton.tag = 55
        eightyNineButton.tag = 89
        oneFourtyFourButton.tag = 144
        questionButton.tag = 200
        infinityButton.tag = 300
        vote = 0
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet var buttons: [UIButton]!
    
    @IBAction func numberClicked(sender: UIButton){
        vote = sender.tag
        print("Button pressed has a tag value of: \(vote)")
        castVote()
    }
    
    func castVote(){
        let url = "http://web-students.armstrong.edu/~jd8944/gulfstream2/insert.php?roomname=\(roomName)&fName=\(fName)&lName=\(lName)&vote=\(vote)"
        let request = NSMutableURLRequest(URL: NSURL(string:url)!)
        request.HTTPMethod = "POST"
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request){data, response, error in
            guard error == nil && data != nil else {
                print("error=\(error)")
                return
            }
            
            let responseString = String(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
        }
        task.resume()
    }
}






























