//
//  HostExistingRoomController.swift
//  PlanningPoker2
//
//  Created by Lee Hope on 12/10/16.
//  Copyright © 2016 Joshua Davis. All rights reserved.
//

import UIKit

class HostExistingRoomController: UIViewController {

    @IBOutlet weak var roomNameTF: UITextField!
    @IBOutlet weak var pwTF: UITextField!
    var roomNameString: String!
    var roomPWString: String!
    var fNameString: String!
    var lNameString: String!
    var confirmed: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue,sender: AnyObject!) {
        let hvc = segue.destinationViewController as! HostViewController;
        hvc.roomName = roomNameString
        hvc.password = roomPWString
    }

    @IBAction func hostRoom(sender: AnyObject) {
        roomNameString = roomNameTF.text!
        roomPWString = pwTF.text!
        
        let url = "http://web-students.armstrong.edu/~jd8944/gulfstream2/verifyroom.php?roomname=\(roomNameString)&roompw=\(roomPWString)"
        let request = NSMutableURLRequest(URL: NSURL(string: url)!)
        request.HTTPMethod = "POST"
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in
            guard error == nil && data != nil else {                                                          // check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let json = try? NSJSONSerialization.JSONObjectWithData(data!, options: .AllowFragments){
                if let jArr = json as? NSArray{
                    for obj in jArr{
                        self.confirmed = obj["Confirmed"] as? String
                        print(self.confirmed)
                    }
                }
                
            }
            if(self.confirmed == "true"){
                dispatch_async(dispatch_get_main_queue()){
                    // will only segue if the php returns true. does nothing otherwise
                    self.performSegueWithIdentifier("existingToHost", sender: nil)
                }
            }
            
        }
        task.resume()
    }


}
