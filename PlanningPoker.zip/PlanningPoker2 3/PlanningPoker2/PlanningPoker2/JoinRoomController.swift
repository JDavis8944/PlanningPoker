//
//  JoinRoomController.swift
//  PlanningPoker2
//
//  Created by Mitzi Davis on 11/23/16.
//  Copyright (c) 2016 Joshua Davis. All rights reserved.
//

import UIKit

class JoinRoomController: UIViewController {
    @IBOutlet weak var roomNameTF: UITextField!
    @IBOutlet weak var roomPWTF: UITextField!
    @IBOutlet weak var fNameTF: UITextField!
    @IBOutlet weak var lNameTF: UITextField!
    var roomNameString: String!
    var roomPWString: String!
    var fNameString: String!
    var lNameString: String!
    var confirmed: String!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue,sender: AnyObject!) {
        //Pass variables to the MemberViewController 
        //so the member doesn't continuously enter their name
        if let mvc = segue.destinationViewController as? MemberViewController{
            mvc.roomName = roomNameString
            mvc.fName = fNameString
            mvc.lName = lNameString
        }
    }
    
    @IBAction func joinRoom(sender: AnyObject) {
        roomNameString = roomNameTF.text!
        roomPWString = roomPWTF.text!
        fNameString = fNameTF.text!
        lNameString = lNameTF.text!
        
        let url = "http://web-students.armstrong.edu/~jd8944/gulfstream2/verifyroom.php?roomname=\(roomNameString)&roompw=\(roomPWString)"
        let request = NSMutableURLRequest(URL: NSURL(string: url)!)
        request.HTTPMethod = "POST"
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in
            guard error == nil && data != nil else {                                                          // check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let json = try? NSJSONSerialization.JSONObjectWithData(data!, options: .AllowFragments){
                if let jArr = json as? NSArray{
                    for obj in jArr{
                        self.confirmed = obj["Confirmed"] as? String
                        print(self.confirmed)
                    }
                }
                
            }
            if(self.confirmed == "true"){
                dispatch_async(dispatch_get_main_queue()){
                    // will only segue if the php returns true. does nothing otherwise
                    self.performSegueWithIdentifier("joinToMemberSegue", sender: nil)
                }
            }
            
        }
        task.resume()
    }

    func confirmRoom(){
        let url = "http://web-students.armstrong.edu/~jd8944/gulfstream2/verifyroom.php?roomname=\(roomNameString)&roompw=\(roomPWString)"
        let request = NSMutableURLRequest(URL: NSURL(string: url)!)
        request.HTTPMethod = "POST"
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in guard error == nil && data != nil else {
            // check for fundamental networking error
            print("error=\(error)")
            return
            }
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)){
            if let json = try? NSJSONSerialization.JSONObjectWithData(data!, options: .AllowFragments){
                if let jArr = json as? NSArray{
                    for obj in jArr{
                        self.confirmed = obj["boolean"] as? String
                        
                    }
            }
        }
        }
        }
        task.resume()
    }
}















