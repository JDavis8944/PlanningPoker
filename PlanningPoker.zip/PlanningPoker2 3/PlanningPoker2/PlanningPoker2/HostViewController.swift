//
//  HostViewController.swift
//  PlanningPoker2
//
//  Created by Mitzi Davis on 11/23/16.
//  Copyright (c) 2016 Joshua Davis. All rights reserved.
//

import UIKit

class HostViewController: UIViewController {
    var roomName: String!
    var password: String!
    @IBOutlet weak var votesTV: UITextView!
    @IBOutlet weak var avgLabel: UILabel!
    @IBOutlet weak var pwLabel: UILabel!
    @IBOutlet weak var roomnameLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        pwLabel.text = password
        roomnameLabel.text = roomName
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func nextTopic(sender: AnyObject) {
        self.votesTV.text = ""
        self.avgLabel.text = ""
        let url = "http://web-students.armstrong.edu/~jd8944/gulfstream2/service2.php?roomname=\(roomName)&service=clearvotes"
        
        let request = NSMutableURLRequest(URL: NSURL(string:url)!)
        request.HTTPMethod = "POST"
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in
            guard error == nil && data != nil else {                                                          // check for fundamental networking error
                print("error=\(error)")
                return
            }

    }
        task.resume()
    }
    

    @IBAction func showVotes(sender: AnyObject) {
        var sum = 0.0
        var avg = 0
        var count = 0
        self.votesTV.text = ""

        let url = "http://web-students.armstrong.edu/~jd8944/gulfstream2/service2.php?roomname=\(roomName)&service=showvotes"
        
        let request = NSMutableURLRequest(URL: NSURL(string:url)!)
        request.HTTPMethod = "POST"
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in
            guard error == nil && data != nil else {                                                          // check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let json = try? NSJSONSerialization.JSONObjectWithData(data!, options: .AllowFragments){
                if let jArr = json as? NSArray{
                    for obj in jArr{
                        let fName = obj["First_Name"] as? String
                        let lName = obj["Last_Name"] as? String
                        let vote = obj["Vote"] as? String
                        count += 1
                        sum += Double(vote!)!
                        dispatch_async(dispatch_get_main_queue()){
                            if vote == "100"{
                            self.votesTV.text.appendContentsOf(fName! + " " + lName! + " voted: 1/2 \n")
                                sum -= 99.5
                            } else if vote == "200"{
                                self.votesTV.text.appendContentsOf(fName! + " " + lName! + " needs it broken down \n")
                                sum -= 200
                            } else if vote == "300"{
                                self.votesTV.text.appendContentsOf(fName! + " " + lName! + " needs a break \n")
                                sum -= 300
                            } else {
                                self.votesTV.text.appendContentsOf(fName! + " " + lName! + " voted: " + vote! + "\n")
                            }
                        }
                    }
                    if count > 0 {
                        dispatch_async(dispatch_get_main_queue()){
                            avg = Int(Int(sum)/count)
                            self.avgLabel.text = String(avg)
                        }
                    }
                }
                
            }
            
            
        }
        task.resume()
    }
    
    
    
}
