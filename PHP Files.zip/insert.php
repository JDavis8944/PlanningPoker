

<?php
    
    // Create connection
	include "../db.php";
    $con=mysqli_connect($host,$username,$password,$db_name);
    
    // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	echo "I connected I guess";
	$roomName = $_GET["roomname"];
    $fName = $_GET["fName"];
	$lName = $_GET["lName"];
    $vote = $_GET["vote"];
    // This SQL statement selects ALL from the table 'Locations'
    $sql = "INSERT INTO $roomName(First_Name,Last_Name,Vote) VALUES('$fName','$lName','$vote');";
    
    // Check if there are results
    if ($result = mysqli_query($con, $sql))
    {

    }
    
    // Close connections
    mysqli_close($con);
    ?>