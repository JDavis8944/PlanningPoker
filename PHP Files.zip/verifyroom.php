<?php

    // Create connection
    include "../db.php";
    $con=mysqli_connect($host,$username,$password,$db_name);
    
    // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    
	$room = $_GET["roomname"];
	$password = $_GET["roompw"];
	$truth = '[{"Confirmed":"true"}]';
	$falth = '[{"Confirmed":"false"}]';
	$roomCheck = "SELECT * FROM ROOMS WHERE Room_Name = '$room' && Password = '$password';";
    // This checks for the existence of a table
	$result = mysqli_query($con,$roomCheck);
	$count = mysqli_num_rows($result);
	if($count==1){
		echo $truth;
	} else {
		echo $falth;
	}	
    // Close connections
    mysqli_close($con);
    ?>