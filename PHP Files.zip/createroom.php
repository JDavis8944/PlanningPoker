<?php
    
    // Create connection
	include "../db.php";
    $con=mysqli_connect($host,$username,$password,$db_name);
    
    // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	echo "I connected I guess";
    $roomname = $_GET["roomname"];
	$roompw = $_GET["roompw"];

    $create = "CREATE TABLE '".$roomname."'(FirstName varchar(255), LastName varchar(255), VoteValue int)";
	$storeTable = "INSERT INTO ROOMS(Room_Name, Password) VALUES('".$roomname."','".$roompw."')";
    
    // Check if the table already exists
	if(mysql_num_rows(mysql_query("SHOW TABLES LIKE '".$roomname."'"))<1){		
       if ($result = mysqli_query($con, $create))
       {
		   if ($result = mysqli_query($con, $storeTable))
		   {
				
		   }
       }
	   
    
    // Close connections
    mysqli_close($con);
    ?>