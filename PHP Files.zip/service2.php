<?php

    // Create connection
    include "../db.php";
    $con=mysqli_connect($host,$username,$password,$db_name);
    
    // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    
    // This SQL statement selects ALL from the table 'Locations'
	$roomName = $_GET["roomname"];
	$service = $_GET["service"];
    $sqlShow = "SELECT * FROM $roomName;";
	$sqlClear = "DELETE FROM $roomName;";
    
	if($service == "showvotes"){
    // Check if there are results
    if ($result = mysqli_query($con, $sqlShow))
    {
        // If so, then create a results array and a temporary one
        // to hold the data
        $resultArray = array();
        $tempArray = array();
        
        // Loop through each row in the result set
        while($row = $result->fetch_object())
        {
            // Add each row into our results array
            $tempArray = $row;
            array_push($resultArray, $tempArray);
        }
        
        // Finally, encode the array to JSON and output the results
        echo json_encode($resultArray,JSON_UNESCAPED_SLASHES);
    }
	 } else if($service == "clearvotes"){
		if($result = mysqli_query($con, $sqlClear))
		{
			echo "Table has been cleared";
		} 
	}
    
    // Close connections
    mysqli_close($con);
    ?>